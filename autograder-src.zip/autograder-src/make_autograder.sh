#!/usr/bin/env bash

echo "Building Autograder..."

zip -r autograder.zip src run_autograder setup.sh

echo "---"
echo "DONE."

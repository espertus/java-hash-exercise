#!/usr/bin/env bash

# Gradescope requires this file, but no additional setup is needed.
